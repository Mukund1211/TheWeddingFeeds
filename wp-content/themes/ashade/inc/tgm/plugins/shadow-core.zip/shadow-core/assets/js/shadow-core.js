/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
"use strict";
